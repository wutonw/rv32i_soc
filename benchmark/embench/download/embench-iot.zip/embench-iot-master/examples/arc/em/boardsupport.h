/* Board support header for generic ARC board

   Copyright (C) 2019 Embecosm Limited

   Contributor Jeremy Bennett <jeremy.bennett@embecosm.com>

   This file is part of Embench.

   SPDX-License-Identifier: GPL-3.0-or-later */

/* Should match board.cfg (and why have to specify it again). */
